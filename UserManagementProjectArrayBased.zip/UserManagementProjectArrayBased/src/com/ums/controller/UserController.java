package com.ums.controller;

import java.util.Scanner;

import com.ums.exceptionhandling.ExceptionHandler;
import com.ums.service.UserServiceInterface;
import com.ums.serviceimpl.UserServiceImpl;

public class UserController {

	public static void main(String[] args) {
		
		System.out.println("--User Application--");
		Scanner sc = new Scanner(System.in);
		
		UserServiceInterface service = new UserServiceImpl();
		
		boolean flag = true;
		
		while (flag) {
			System.out.println("1. CREATE USER");
			System.out.println("2. Display User");
			System.out.println("3. Delete User");
			System.out.println("4. Exit ");
			
			
			int ch = ExceptionHandler.getValidChoice();
			
			switch (ch) {
			case 1: {
				service.createUser();
				break;
			}
			case 2: {
				service.displayDetailsOfUser();;
				break;
			}
			case 3: {
				service.deleteUser();;
				break;
			}
			case 4: {
				flag = false;
				break;
			}
			default:
				System.out.println("Invalid choice!!");
			}
			
		}
	}
}
