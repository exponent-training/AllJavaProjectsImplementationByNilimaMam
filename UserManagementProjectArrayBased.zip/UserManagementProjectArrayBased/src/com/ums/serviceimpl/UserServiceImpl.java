package com.ums.serviceimpl;

import java.util.Scanner;

import com.ums.model.User;
import com.ums.service.UserServiceInterface;
import com.ums.validator.ValidationChecker;

public class UserServiceImpl implements UserServiceInterface {

	static Scanner sc = new Scanner(System.in);
	User[] usersArray = new User[5]; // 0 1 2 3 4 n=2

	@Override
	public void createUser() {

		System.out.println("enter no. of users you want to insert:");
		int n = sc.nextInt();// 0 1
		for (int i = 0; i < n; i++) {
			User user = new User();
			System.out.println("Enter userId: ");
			user.setUserId(sc.nextInt());

			System.out.println("Enter name:");
			user.setUsername(sc.next());

			sc.nextLine();
			System.out.println("enter aadhar no:");
			user.setAadharcardNo(sc.nextLine());

			System.out.println("enter pan no:");
			user.setPancardNo(sc.next());
			;

			System.out.println("enter emailId:");
			user.setEmailId(sc.next());

			System.out.println("enter address:");
			user.setAddress(sc.next());

			System.out.println("enter Mobile no:");
			user.setContactNo(sc.nextLong());

			usersArray[i] = user;
			System.out.println("User created for " + i + " index..");

		}

		System.out.println("User created successfully!!");
	}

	@Override
	public void displayDetailsOfUser() {
		System.out.println("Users details:");

		for (User user : usersArray) {
			if (user != null) {
				System.out.println(user);
			}
		}

	}
	
	@Override
	public void deleteUser() {
		System.out.println("In delete operation:");

		// int userIdInput = getValidUserId();

		System.out.println("Enter the userId you want to delete:");
		int inUserId = sc.nextInt();
		
		for(int i = 0; i<usersArray.length;i++) {
			if(usersArray[i] != null && inUserId == usersArray[i].getUserId()) {
				usersArray[i]=null;
			}
		}
		System.out.println("users list after deleting one user with user id "+inUserId);
		displayDetailsOfUser();
	}
	
	@Override
	public void updateUser() {
		// TODO Auto-generated method stub

	}


	public int getValidUserId() {
		return 0;

	}
}








