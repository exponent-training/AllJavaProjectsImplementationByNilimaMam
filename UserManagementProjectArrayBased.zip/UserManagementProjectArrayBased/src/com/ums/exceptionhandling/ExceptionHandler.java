package com.ums.exceptionhandling;

import java.util.Scanner;

public class ExceptionHandler {
	
	
	
	public static int getValidChoice() {
		 Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice:");
		int ch;
		
		try {
			ch = sc.nextInt();// abc
		} catch (Exception e) {
			System.out.println("Invalid choice, please enter the valid choice.");
			return getValidChoice();
		}
		
		return ch;
		
	}

}
