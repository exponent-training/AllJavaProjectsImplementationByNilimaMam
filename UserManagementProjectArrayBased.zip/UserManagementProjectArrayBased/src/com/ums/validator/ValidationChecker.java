package com.ums.validator;

import java.util.Scanner;
import java.util.regex.Pattern;

public class ValidationChecker {
	static Scanner sc = new Scanner(System.in);

	public static long getValidContactNo() {

		System.out.println("Enter user's contact no:");
		long contactNo = sc.nextLong();
		String strContactNo = String.valueOf(contactNo);
		if (strContactNo.length() == 10
				&& (strContactNo.startsWith("7") || strContactNo.startsWith("8") || strContactNo.startsWith("9"))) {
			System.out.println("Valid contact no.");
		} else {
			System.out.println("Invalid contact no.");
			getValidContactNo();
		}
		return contactNo;
	}

	public static String getValidUsername() {

		System.out.println("Enter user's name:");
		String username = sc.next();
		
		if (Pattern.matches("[A-Za-z]+", username)) {
			System.out.println("Valid user name");
		} else {
			System.out.println("Invalid user name");
			getValidUsername();
		}
		return username;
	}

	
	public static String getValidPanCardNo() {

		System.out.println("Enter user's panno:");
		String pancardno = sc.next();
		
		if (Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}", pancardno)) {
			System.out.println("Valid pancardno");
		} else {
			System.out.println("Invalid pancardno");
			getValidPanCardNo();
		}
		return pancardno;
	}
	
	public static String getValidAadharCardNo() {

		sc.nextLine();
		System.out.println("Enter user's aadharcardno:");
		String aadharcardno = sc.nextLine();
		
		if (Pattern.matches("[2-9]{1}[0-9]{3}[ ]{1}[0-9]{4}[ ]{1}[0-9]{4}", aadharcardno)) {
			System.out.println("Valid aadharcardno");
		} else {
			System.out.println("Invalid aadharcardno");
			getValidAadharCardNo();
		}
		return aadharcardno;
	}
	
	
	
	
	
	
	
	
}
