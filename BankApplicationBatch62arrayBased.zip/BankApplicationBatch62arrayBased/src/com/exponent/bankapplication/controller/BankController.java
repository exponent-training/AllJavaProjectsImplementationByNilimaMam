package com.exponent.bankapplication.controller;

import java.util.Scanner;

import com.exponent.bankapplication.service.RBI;
import com.exponent.bankapplication.serviceimpl.SBI;

public class BankController {

	public static void main(String[] args) {

		System.out.println("*******Welcome to Bank application*********8");
		Scanner sc = new Scanner(System.in);

		RBI rbi = new SBI();

		boolean flag = true;

		while (flag) {
			System.out.println("-----------------------------------");
			System.out.println("1. Create Account  ");
			System.out.println("2. Show Account details  ");
			System.out.println("3. Show Account Balance  ");
			System.out.println("4. Withdraw the Amount");
			System.out.println("5. Deposite the Amount");
			System.out.println("6. Update Account details");
			System.out.println("7. Exit");
			System.out.println("-------------------------------------");

			System.out.println("Enter your choice in between 1 to 7: ");
			int ch = sc.nextInt();

			switch (ch) {
			case 1:
				rbi.createAccount();
				break;
			case 2:
				rbi.showAccountDetails();
				break;
			case 3:
				rbi.showAccountBalance();
				break;

			case 4:
				rbi.withdrawAmount();
				break;

			case 5:
				rbi.depositeAmount();
				break;

			case 6:
				rbi.updateDetails();
				break;

			case 7:
				flag = false;
				System.out.println("Thank you for visiting.");
				break;
			default:
				System.out.println("Invalid user's choice, please enter the proper choice");
				break;
			}
		}
	}

}
