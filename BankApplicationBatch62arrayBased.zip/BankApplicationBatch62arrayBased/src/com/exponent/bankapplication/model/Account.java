package com.exponent.bankapplication.model;

public class Account {

	private long accountno;

	private String accountholdername;

	private String address;

	private String email;

	private String aadharcardno;

	private String pancardno;

	private long mobileno;

	private double balance;

	public long getAccountno() {
		return accountno;
	}

	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}

	public String getAccountholdername() {
		return accountholdername;
	}

	public void setAccountholdername(String accountholdername) {
		this.accountholdername = accountholdername;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAadharcardno() {
		return aadharcardno;
	}

	public void setAadharcardno(String aadharcardno) {
		this.aadharcardno = aadharcardno;
	}

	public String getPancardno() {
		return pancardno;
	}

	public void setPancardno(String pancardno) {
		this.pancardno = pancardno;
	}

	public long getMobileno() {
		return mobileno;
	}

	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accountno=" + accountno + ", accountholdername=" + accountholdername + ", address=" + address
				+ ", email=" + email + ", aadharcardno=" + aadharcardno + ", pancardno=" + pancardno + ", mobileno="
				+ mobileno + ", balance=" + balance + "]";
	}

}
