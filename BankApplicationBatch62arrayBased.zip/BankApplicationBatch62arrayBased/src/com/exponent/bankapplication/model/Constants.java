package com.exponent.bankapplication.model;

public class Constants {
	
	public static final int max_size = 5;

}
