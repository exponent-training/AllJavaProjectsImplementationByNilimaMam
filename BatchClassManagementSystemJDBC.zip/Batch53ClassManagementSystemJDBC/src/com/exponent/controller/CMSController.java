package com.exponent.controller;

import java.util.Scanner;

import com.exponent.service.CMSServiceImpl;
import com.exponent.service.CMSServiceInterface;

public class CMSController {

	public static void main(String[] args) {

		System.out.println("Welcome to Class Mangement System");

		Scanner sc = new Scanner(System.in);

		boolean flag = true;

		CMSServiceInterface cms = new CMSServiceImpl();

		while (flag) {

			System.out.println("1. Add Course");
			System.out.println("2. Display Course");
			System.out.println("3. Add Faculty");
			System.out.println("4. Display Faculty");
			System.out.println("5. Add Batch");
			System.out.println("6. Display Batch");
			System.out.println("7. Add Student");
			System.out.println("8. Display Student");
			System.out.println("9. Exit");
			System.out.println("------------------------");
			
			System.out.println("Enter choice:");

			int ch = sc.nextInt();

			switch (ch) {
			case 1:
				cms.addCourse();
				break;

			case 2:
				cms.displayCourse();
				;
				break;

			case 3:
				cms.addFaculty();
				;
				break;

			case 4:
				cms.displayFaculty();
				break;

			case 11:
				flag = false;
				break;

			default:

				System.out.println("Wrong choice.");
				break;
			}

		}
	}

}
