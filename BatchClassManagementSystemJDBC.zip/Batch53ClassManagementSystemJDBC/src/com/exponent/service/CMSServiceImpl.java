package com.exponent.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.exponent.config.MyConnection;

public class CMSServiceImpl implements CMSServiceInterface {

	Scanner sc = new Scanner(System.in);

	@Override
	public void addCourse() {
		try {
			Connection connection = MyConnection.getConnection();
			System.out.println("Enter no. of courses you want to add:");
			int n = sc.nextInt();
			for (int i = 1; i <= n; i++) {
				System.out.println("Enter cid:");
				int cid = sc.nextInt();
				System.out.println("Enter cname:");
				String cname = sc.next();
				String sql = "insert into course values(?,?)";
				PreparedStatement pst = connection.prepareStatement(sql);
				pst.setInt(1, cid);
				pst.setString(2, cname);
				pst.execute();
				System.out.println("success!!");

			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Override
	public void displayCourse() {
		try {
			Connection connection = MyConnection.getConnection();

			String sql = "select * from course";

			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet result = pst.executeQuery();
			System.out.println("Course details");
			while (result.next()) {
				System.out.println("------------------------");
				System.out.println(result.getInt(1));
				System.out.println(result.getString(2));
				System.out.println("------------------------");
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Override
	public void addFaculty() {
		try {
			Connection connection = MyConnection.getConnection();
			System.out.println("Enter no. of faculties you want to add:");
			int n = sc.nextInt();
			for (int i = 1; i <= n; i++) {
				System.out.println("Enter fid:");
				int fid = sc.nextInt();
				System.out.println("Enter fname:");
				String fname = sc.next();
				System.out.println("Enter cid you want add in faculty from below list:");
				displayCourse();
				int cid = sc.nextInt();
				String query = "insert into faculty values(?,?,?)";
				PreparedStatement pst = connection.prepareStatement(query);
				pst.setInt(1, fid);
				pst.setString(2, fname);
				pst.setInt(3, cid);
				pst.execute();
				System.out.println("success!!");

			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Override
	public void displayFaculty() {
		try {
			Connection connection = MyConnection.getConnection();

			String sql = "select course.cid,course.cname,faculty.fid,faculty.fname from course inner join faculty"
					+ " on course.cid = faculty.cid";

			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet result = pst.executeQuery();
			System.out.println("faculty details along with course");
			while (result.next()) {
				System.out.println("------------------------");
				System.out.println(result.getInt(1));
				System.out.println(result.getString(2));
				System.out.println(result.getInt(3));
				System.out.println(result.getString(4));
				System.out.println("------------------------");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void addBatch() {
		// TODO Auto-generated method stub

	}

	@Override
	public void displayBatch() {
String sql = "select course.cid,course.cname,faculty.fid,faculty.fname,batch.bid,batch.bname from course inner join faculty "
	+"on course.cid = faculty.cid inner join batch on faculty.fid = batch.fid";

	}

	@Override
	public void addStudent() {
		// TODO Auto-generated method stub

	}

	@Override
	public void displayStudent() {
		// TODO Auto-generated method stub

	}

}
