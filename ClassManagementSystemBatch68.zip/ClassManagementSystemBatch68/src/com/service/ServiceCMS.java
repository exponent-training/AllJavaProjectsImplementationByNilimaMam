package com.service;

public interface ServiceCMS {
	
	void addCourse();

	void displayCourse();
	
	void addFaculty();

	void displayFaculty();
	
	void addBatch();

	void displayBatch();
	
	void addStudent();

	void displayStudent();
	
	void updateFunctions();
	
	void deleteFunctions();
}
