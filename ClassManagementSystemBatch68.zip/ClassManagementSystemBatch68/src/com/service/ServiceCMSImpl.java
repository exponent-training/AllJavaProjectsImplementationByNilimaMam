package com.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.model.Batch;
import com.model.Course;
import com.model.Faculty;
import com.model.Student;

public class ServiceCMSImpl implements ServiceCMS {

	Scanner sc = new Scanner(System.in);
	 List<Course> cList = new ArrayList<Course>();
	 List<Faculty> fList = new ArrayList<Faculty>();
	 List<Batch> bList = new ArrayList<Batch>();
	 List<Student> sList = new ArrayList<Student>();
	 
	@Override
	public void addCourse() {
		System.out.println("Enter no. of corses you want to add:");
		int n = sc.nextInt();
		for(int i =0;i<n;i++) {//2 
			Course c = new Course();
			System.out.println("enter cid:");
			int cid = sc.nextInt();
			c.setCid(cid);
			System.out.println("enter cname:"); // java  python
			String cname = sc.next();
			c.setCname(cname);
			cList.add(c);  
		}
		
		System.out.println("courses added successfully!!");
		
	}

	@Override
	public void displayCourse() {
	System.out.println("Course details:");
	
		for(Course course:cList) {
			System.out.println(course);
		}
		
	}

	@Override
	public void addFaculty() {
		System.out.println("Enter no. of faculties you want to add:"); 
		int n = sc.nextInt();
		for(int i =0;i<n;i++) {  
			Faculty f = new Faculty();
			System.out.println("enter fid=");
			int fid = sc.nextInt();
			f.setFid(fid);
			System.out.println("enter fanme:"); // sumit krishna
			String fanme = sc.next();
			f.setFname(fanme);
			System.out.println("enter cid from below mentioned course list, that user wants to allot to a Faculty:");
			displayCourse();  
			int cidIN = sc.nextInt();  
			for(Course courseAllot :cList) {
				if (courseAllot!= null && cidIN==courseAllot.getCid()) {  
					f.setCourse(courseAllot);
				}
			}
			fList.add(f);  
		}
		
		System.out.println("faculties added successfully!!");

		
	}

	@Override
	public void displayFaculty() {
	System.out.println("Faculty details:");
	for(Faculty faculty:fList) {
		System.out.println(faculty);
	}
		
	}

	@Override
	public void addBatch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayBatch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addStudent() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayStudent() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateFunctions() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteFunctions() {
		// TODO Auto-generated method stub
		
	}

}
