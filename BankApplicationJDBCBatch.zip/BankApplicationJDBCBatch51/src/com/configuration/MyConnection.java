package com.configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
	
	private MyConnection() {
		
	}
	
	public static Connection connection = null;
	
	public static Connection getConnection() throws ClassNotFoundException,SQLException {
		if (connection == null) {
			
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/test51", "root", "root");
			
		}
		return connection;
	}
	
}






