package com.controller;

import java.util.Scanner;

import com.service.BankService;
import com.service.BankServiceImpl;

public class BankController {

	public static void main(String[] args) {

		System.out.println("Welcome to Bank Application");

		Scanner sc = new Scanner(System.in);

		boolean flag = true;

		BankService bs = new BankServiceImpl();

		while (flag) {

			System.out.println("***************");
			System.out.println("  1. Register Account details");
			System.out.println("  2. Display Account details");
			System.out.println("  3. Show Account Balance");
			System.out.println("  4. Withdraw Amount");
			System.out.println("  5. Deposit Amount");
			System.out.println("  6. Update Details");
			System.out.println("  7. Exit the Application");

			System.out.println("enter choice option:");

			int ch = getValidChoice();

			switch (ch) {
			case 1:
				bs.registerAccount();
				break;
			case 2:
				bs.displayAccount();
				break;
			case 3:
				bs.showAccountBalance();
				break;
			case 4:
				bs.withdrawAmount();
				break;
			case 5:
				bs.depositAmount();
				break;
			case 6:
				bs.updateAccountDetails();
				break;
			case 7:
				flag = false;
				break;
			default:
				break;
			}
		}
	}
	
	public static int getValidChoice() {
		System.out.println("Enter choice option:");	
		Scanner sc = new Scanner(System.in);
		int ch;
		try {
			ch = sc.nextInt();
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println("Invalid choice!!");
			return getValidChoice();
		}
		return ch;
	}

}
