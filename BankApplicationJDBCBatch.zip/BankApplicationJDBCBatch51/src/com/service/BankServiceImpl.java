package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.configuration.MyConnection;

public class BankServiceImpl implements BankService {

	@Override
	public void registerAccount() {
		try {
			Connection connection = MyConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			System.out.println("How many accounts you want add: ");
			int n = sc.nextInt();
			for (int i = 1; i <= n; i++) {
				String sql = "insert into account values(?,?,?,?,?,?,?)";
				PreparedStatement pst = connection.prepareStatement(sql);
				System.out.println("Enter accNo:");
				pst.setLong(1, sc.nextLong());
				System.out.println("Enter name:");
				pst.setString(2, sc.next());
				System.out.println("enter address:");
				pst.setString(3, sc.next());
				System.out.println("Enter balance:");
				pst.setDouble(4, sc.nextDouble());
				System.out.println("Enter mobile no:");
				pst.setLong(5, sc.nextLong());
				System.out.println("Enter aadharno:");
				pst.setString(6, sc.next());
				System.out.println("Enter pancardno:");
				pst.setString(7, sc.next());
				pst.execute();
				System.out.println("data inserted successfully!!");
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Override
	public void displayAccount() {
		try {
			Connection connection = MyConnection.getConnection();
			String sql = "select * from account";
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet res = pst.executeQuery();
			System.out.println("Account details:");
			while (res.next()) {
				System.out.println(res.getInt(1));
				System.out.println(res.getString(2));
				System.out.println(res.getString(3));
				System.out.println(res.getDouble(4));
				System.out.println(res.getLong(5));
				System.out.println(res.getString(6));
				System.out.println(res.getString(7));
				System.out.println("-------------");
			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Override
	public void showAccountBalance() {
		// TODO Auto-generated method stub

	}

	@Override
	public void withdrawAmount() {
		try {
			Connection connection = MyConnection.getConnection();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter account no.= ");
			long accNoIn = sc.nextLong();
			System.out.println("Enter withdra amt= ");
			double withdrawAmt = sc.nextDouble();
			double updatedAmt = 0;
			String sql = "select balance from account where accountNo=?";
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setLong(1, accNoIn);
			ResultSet res = pst.executeQuery();
			while (res.next()) {
				double amtBalance = res.getDouble("balance");
				if (amtBalance > withdrawAmt) {
					updatedAmt = amtBalance - withdrawAmt;
				} else {
					System.out.println("insuffient amt!!");
				}
			}
			String sql1 = "update account set balance=? where accountNo=?";
			PreparedStatement pst1 = connection.prepareStatement(sql1);
			pst1.setDouble(1, updatedAmt);
			pst1.setLong(2, accNoIn);
			pst1.executeUpdate();
			System.out.println("balance updated successfully for accNo: " + accNoIn);

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	@Override
	public void depositAmount() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAccountDetails() {
		// TODO Auto-generated method stub

	}

}
