package com.service;

public interface BankService {

	public void registerAccount();
	
	public void displayAccount();
	
	public void showAccountBalance();
	
	public void withdrawAmount();
	
	public void depositAmount();
	
	public void updateAccountDetails();
	
 }
