package com.ums.model;

public class User {

	
	private int userId;
	
	private String username;
	
	private String aadharcardNo;
	
	private String pancardNo;
	
	private String emailId;
	
	private long contactNo;
	
	private String address;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getAadharcardNo() {
		return aadharcardNo;
	}

	public void setAadharcardNo(String aadharcardNo) {
		this.aadharcardNo = aadharcardNo;
	}

	public String getPancardNo() {
		return pancardNo;
	}

	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getContactNo() {
		return contactNo;
	}

	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", username=" + username + ", aadharcardNo=" + aadharcardNo + ", pancardNo="
				+ pancardNo + ", emailId=" + emailId + ", contactNo=" + contactNo + ", address=" + address + "]";
	}
	
	
}
