package com.ums.service;

public interface UserServiceInterface {
	
	public void createUser();
	
	public void displayDetailsOfUser();
	
	public void updateUser();
	
	public void deleteUser();

}
