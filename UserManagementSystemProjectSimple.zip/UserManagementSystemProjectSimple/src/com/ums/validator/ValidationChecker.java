package com.ums.validator;

import java.util.Scanner;
import java.util.regex.Pattern;

public class ValidationChecker {
	static Scanner sc = new Scanner(System.in);

	public static String checkValidUsername() {

		System.out.println("Enter UserName:");
		String username = sc.next();
		if (Pattern.matches("[A-Za-z]+", username)) {
			System.out.println("User name is valid.");
		} else {
			System.out.println("User name is not valid.");
			return checkValidUsername();
		}
		return username;
	}

	public static long checkContactNo() {

		System.out.println("Enter contact no:");
		long mobno = sc.nextLong();
		String mobnoStr = String.valueOf(mobno);
		if (mobnoStr.length() == 10 && (mobnoStr.startsWith("9") || mobnoStr.startsWith("8") || mobnoStr.startsWith("7"))) {
			System.out.println("Valid contact no.");
		} else {
			System.out.println("Not Valid contact no.");
			return checkContactNo();
		}
		return mobno;
		
	}
	
	public static String checkPancardNo() {

		System.out.println("Enter pancard no:");
		String panno = sc.next();
		if (Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}", panno)) {
			System.out.println("Valid Panno");
		} else {
			System.out.println("Not Valid Panno");
			return checkPancardNo();
		}
		return panno;
		
	}
	
	public static String checkAadharcardNo() {
		sc.nextLine();
		System.out.println("Enter aadhar no:");
		String aadharno = sc.nextLine();
		if (Pattern.matches("[2-9]{1}[0-9]{3}[ ]?[0-9]{4}[ ]?[0-9]{4}",aadharno)) {
			System.out.println("Valid aadharno");//5703 6788 7841
		} else {
			System.out.println("Not Valid aadharno");
			return checkAadharcardNo();
		}
		return aadharno;
		
	}
	
	public static String checkEmailId() {

		System.out.println("Enter emailid:");
		String email = sc.next();
		if (Pattern.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}", email)) {
			System.out.println("Valid email");
		} else {
			System.out.println("Not email aadharno");
			return checkEmailId();
		}
		return email;
		
	}

	
}








