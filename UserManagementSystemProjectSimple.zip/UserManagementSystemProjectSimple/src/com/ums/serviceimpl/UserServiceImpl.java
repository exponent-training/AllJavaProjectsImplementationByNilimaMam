package com.ums.serviceimpl;

import java.util.Scanner;

import com.ums.model.User;
import com.ums.service.UserServiceInterface;
import com.ums.validator.ValidationChecker;

public class UserServiceImpl implements UserServiceInterface {
	 User user = new User();
	@Override
	public void createUser() {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter UserId:");
		 int userid = sc.nextInt();
		 user.setUserId(userid);
		 String username = ValidationChecker.checkValidUsername();
		 user.setUsername(username);		 
		 long cotactNo = ValidationChecker.checkContactNo();
		 user.setContactNo(cotactNo);		 
		 String panno = ValidationChecker.checkPancardNo();
		 user.setPancardNo(panno);
		 String aadharno = ValidationChecker.checkAadharcardNo();
		 user.setAadharcardNo(aadharno);		 
		 String emailId = ValidationChecker.checkEmailId();
		 user.setEmailId(emailId);
	}
	@Override
	public void displayDetailsOfUser() {
		System.out.println("User details:");
		System.out.println(user);
		
	}

	@Override
	public void updateUser() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser() {
		// TODO Auto-generated method stub
		
	}
	
}
